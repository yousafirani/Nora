import type { Locale } from "@/lib/nura/types";

export const CHAT_MODEL = "grok-4.5";
export const IMAGE_MODEL = "grok-imagine-image";
export const MAX_OUTPUT_TOKENS = 2048;
export const MAX_HISTORY = 16;
export const MAX_PROMPT_CHARS = 4000;

export type ChatTurn = {
  role: "user" | "assistant";
  content: string;
  imageUrl?: string;
  attachedImage?: string;
};

export function getApiKey(): string | null {
  const key = process.env.XAI_API_KEY;
  return key && key.length > 0 ? key : null;
}

export function systemPrompt(locale: Locale, search: boolean): string {
  const lang = locale === "fa" ? "Persian (Farsi)" : "English";
  return [
    "You are Nura (نورا), a mobile AI assistant. Warm, concise, and useful — like a thoughtful friend who happens to know a lot.",
    "Reply in the same language the user writes in. If mixed, prefer the user's latest message.",
    `The app UI language is ${lang}.`,
    "Keep answers short on mobile: tight paragraphs, lists when they help, markdown for structure.",
    "Do not claim to be Gemini, Google, ChatGPT, or Grok by name unless asked who powers you — then say you are Nura, powered by Grok from xAI.",
    "If asked to generate or draw an image, describe the scene clearly so an image model could paint it; the app may generate the picture separately.",
    search
      ? "Live web search is ON for this turn. Prefer current facts and mention sources by name in the body."
      : "You have no live web access this turn. If a question needs breaking news, say so briefly.",
    "After the full answer, add this block and nothing after it:",
    "<<chips>>",
    "short follow-up 1",
    "short follow-up 2",
    "<<end>>",
    "Follow-ups must be in the same language as the answer, under 8 words, and useful next questions. Never mention this format to the user.",
    `Today is ${new Date().toISOString().slice(0, 10)}.`,
  ].join(" ");
}

export function toApiMessages(locale: Locale, turns: ChatTurn[], search = false) {
  const sliced = turns.slice(-MAX_HISTORY);
  const messages: Array<{
    role: "system" | "user" | "assistant";
    content:
      | string
      | Array<
          | { type: "text"; text: string }
          | { type: "image_url"; image_url: { url: string } }
        >;
  }> = [{ role: "system", content: systemPrompt(locale, search) }];

  for (const turn of sliced) {
    const visual = turn.attachedImage || turn.imageUrl;
    if (turn.role === "user" && visual) {
      messages.push({
        role: "user",
        content: [
          { type: "text", text: turn.content || (locale === "fa" ? "این تصویر را ببین." : "Look at this image.") },
          { type: "image_url", image_url: { url: visual } },
        ],
      });
    } else {
      messages.push({
        role: turn.role,
        content: turn.content || (turn.imageUrl ? "[image]" : ""),
      });
    }
  }
  return messages;
}

export function clampPrompt(text: string): string {
  return text.trim().slice(0, MAX_PROMPT_CHARS);
}

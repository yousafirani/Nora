export type StreamMeta = {
  citations?: string[];
};

export async function readChatStream(
  stream: ReadableStream<Uint8Array>,
  onDelta: (text: string) => void,
  signal: AbortSignal,
  onMeta?: (meta: StreamMeta) => void,
): Promise<void> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const citations = new Set<string>();

  const abort = () => {
    void reader.cancel();
  };
  signal.addEventListener("abort", abort, { once: true });

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const raw of lines) {
        const line = raw.trim();
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        try {
          const json = JSON.parse(data) as {
            choices?: { delta?: { content?: string } }[];
            citations?: string[];
          };
          const token = json.choices?.[0]?.delta?.content;
          if (typeof token === "string" && token.length > 0) onDelta(token);
          if (Array.isArray(json.citations)) {
            for (const c of json.citations) {
              if (typeof c === "string" && c.startsWith("http")) citations.add(c);
            }
          }
        } catch {
          // ignore malformed sse chunks
        }
      }
    }
  } finally {
    signal.removeEventListener("abort", abort);
    if (citations.size > 0) onMeta?.({ citations: [...citations].slice(0, 6) });
  }
}

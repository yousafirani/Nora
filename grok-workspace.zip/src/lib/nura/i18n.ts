import type { Locale } from "./types";

export const STR = {
  fa: {
    appName: "نورا",
    greetingMorning: "صبح بخیر",
    greetingNoon: "ظهر بخیر",
    greetingAfternoon: "عصر بخیر",
    greetingEvening: "شب بخیر",
    intro: "من نورا هستم",
    subtitle: "چطور می‌تونم کمکت کنم؟",
    placeholder: "از نورا بپرس",
    placeholderImage: "تصویر را توصیف کن",
    send: "ارسال",
    stop: "توقف",
    listening: "در حال گوش دادن…",
    newChat: "گفتگوی جدید",
    chats: "گفتگوها",
    emptyChats: "هنوز گفتگویی نداری",
    settings: "تنظیمات",
    language: "زبان",
    theme: "ظاهر",
    light: "روشن",
    dark: "تیره",
    attach: "پیوست تصویر",
    camera: "دوربین",
    gallery: "گالری",
    createImage: "ساخت تصویر",
    imageMode: "حالت تصویر — توصیف را بفرست",
    copy: "کپی",
    copied: "کپی شد",
    speak: "خواندن",
    delete: "حذف",
    close: "بستن",
    thinking: "در حال فکر کردن",
    drawing: "در حال ساخت تصویر",
    errorGeneric: "نورا الان پاسخ نداد. دوباره تلاش کن.",
    errorUnavailable: "هوش مصنوعی در این محیط در دسترس نیست.",
    errorImage: "ساخت تصویر انجام نشد. توصیف را کوتاه‌تر یا واضح‌تر کن.",
    powered: "پاسخ‌ها با Grok ساخته می‌شوند",
    you: "شما",
    nura: "نورا",
    untitled: "گفتگوی تازه",
    live: "گفتگوی زنده",
    liveHint: "برای حرف زدن صبر کن؛ برای قطع کردن ستاره را لمس کن",
    listeningLive: "گوش می‌دهم…",
    thinkingLive: "دارم فکر می‌کنم…",
    speakingLive: "در حال پاسخ",
    endLive: "پایان گفتگو",
    liveUnsupported: "گفتگوی صوتی در این مرورگر پشتیبانی نمی‌شود.",
    regenerate: "دوباره بنویس",
    search: "جستجوی وب",
    searchOn: "جستجوی وب روشن است",
    sources: "منابع",
    download: "دانلود",
    chips: {
      write: { label: "کمک کن بنویسم", prompt: "یک متن رسمی و کوتاه برای درخواست مرخصی یک‌روزه از مدیر بنویس." },
      explain: { label: "یک موضوع را توضیح بده", prompt: "کامپیوتر کوانتومی را طوری توضیح بده که یک نوجوان ۱۶ ساله بفهمد." },
      image: { label: "یک تصویر بساز", prompt: "یک تصویر سینمایی از کویر ایران در غروب، با سایه‌های بلند، تپه‌های شنی و نور طلایی." },
      translate: { label: "ترجمه کن", prompt: "این جمله را به انگلیسی روان و طبیعی ترجمه کن: زندگی جایی جریان دارد که جرئت می‌کنی آرام بایستی." },
      plan: { label: "برنامه امروز", prompt: "یک برنامهٔ واقع‌بینانه برای امروز بچین: کار عمیق صبح، ورزش عصر، و زمان استراحت بدون افراط." },
      summarize: { label: "خلاصه کن", prompt: "فرق هوش مصنوعی مولد و یادگیری ماشین کلاسیک را در چند نکتهٔ کوتاه خلاصه کن." },
    },
  },
  en: {
    appName: "Nura",
    greetingMorning: "Good morning",
    greetingNoon: "Good afternoon",
    greetingAfternoon: "Good afternoon",
    greetingEvening: "Good evening",
    intro: "I'm Nura",
    subtitle: "How can I help you today?",
    placeholder: "Ask Nura",
    placeholderImage: "Describe an image",
    send: "Send",
    stop: "Stop",
    listening: "Listening…",
    newChat: "New chat",
    chats: "Chats",
    emptyChats: "No conversations yet",
    settings: "Settings",
    language: "Language",
    theme: "Appearance",
    light: "Light",
    dark: "Dark",
    attach: "Attach image",
    camera: "Camera",
    gallery: "Gallery",
    createImage: "Create image",
    imageMode: "Image mode — describe what to make",
    copy: "Copy",
    copied: "Copied",
    speak: "Speak",
    delete: "Delete",
    close: "Close",
    thinking: "Thinking",
    drawing: "Creating image",
    errorGeneric: "Nura couldn't reply. Try again.",
    errorUnavailable: "AI is not available in this environment.",
    errorImage: "Couldn't create that image. Try a clearer description.",
    powered: "Replies are generated with Grok",
    you: "You",
    nura: "Nura",
    untitled: "New chat",
    live: "Live talk",
    liveHint: "Wait to speak · tap the sparkle to interrupt",
    listeningLive: "Listening…",
    thinkingLive: "Thinking…",
    speakingLive: "Speaking",
    endLive: "End live",
    liveUnsupported: "Voice chat isn't supported in this browser.",
    regenerate: "Regenerate",
    search: "Web search",
    searchOn: "Web search is on",
    sources: "Sources",
    download: "Download",
    chips: {
      write: { label: "Help me write", prompt: "Write a short, professional sick-day email to my manager." },
      explain: { label: "Explain a topic", prompt: "Explain quantum computers as if I were sixteen." },
      image: { label: "Create an image", prompt: "A cinematic photograph of a desert at sunset, long shadows, sand dunes, golden light." },
      translate: { label: "Translate", prompt: "Translate this into natural Persian: Life happens where you dare to stand still." },
      plan: { label: "Plan my day", prompt: "Make a realistic plan for today: deep work in the morning, exercise later, and actual rest — no overkill." },
      summarize: { label: "Summarize", prompt: "Summarize the difference between generative AI and classical machine learning in a few tight bullets." },
    },
  },
} as const;

export type Copy = (typeof STR)[Locale];

export function greetingForHour(locale: Locale, hour: number): string {
  const t = STR[locale];
  if (hour < 12) return t.greetingMorning;
  if (hour < 15) return t.greetingNoon;
  if (hour < 19) return t.greetingAfternoon;
  return t.greetingEvening;
}

export function hasPersian(text: string): boolean {
  return /[\u0600-\u06FF]/.test(text);
}

export function dirForText(text: string): "rtl" | "ltr" {
  return hasPersian(text) ? "rtl" : "ltr";
}

export function looksLikeImagePrompt(text: string): boolean {
  const t = text.trim();
  if (/^(draw|generate|create|make)\s+(me\s+)?(an?\s+)?(image|picture|illustration|photo)\b/i.test(t)) {
    return true;
  }
  if (/(تصویر|عکس|نقاشی)\s*(از|بساز|بکش|کن)/.test(t)) return true;
  if (/^(یک\s+)?(تصویر|عکس|نقاشی)\b/.test(t)) return true;
  return false;
}

export function titleFromPrompt(text: string, fallback: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return fallback;
  const max = 42;
  return clean.length > max ? `${clean.slice(0, max).trim()}…` : clean;
}

export function hostnameOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

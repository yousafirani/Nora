import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ChatMessage, ComposerMode, Conversation, Locale, Theme } from "./types";

const MAX_CHATS = 40;
const MAX_MESSAGES = 80;

type NuraState = {
  hydrated: boolean;
  locale: Locale;
  theme: Theme;
  conversations: Conversation[];
  activeId: string | null;
  composerMode: ComposerMode;
  setHydrated: () => void;
  setLocale: (locale: Locale) => void;
  setTheme: (theme: Theme) => void;
  setComposerMode: (mode: ComposerMode) => void;
  newChat: () => string;
  setActive: (id: string | null) => void;
  deleteChat: (id: string) => void;
  appendMessage: (chatId: string, message: ChatMessage) => void;
  patchMessage: (chatId: string, messageId: string, patch: Partial<ChatMessage>) => void;
  touchTitle: (chatId: string, title: string) => void;
  removeLastAssistant: (chatId: string) => void;
};

function uid(): string {
  return crypto.randomUUID();
}

export const useNuraStore = create<NuraState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      locale: "fa",
      theme: "light",
      conversations: [],
      activeId: null,
      composerMode: "chat",
      setHydrated: () => set({ hydrated: true }),
      setLocale: (locale) => set({ locale }),
      setTheme: (theme) => set({ theme }),
      setComposerMode: (composerMode) => set({ composerMode }),
      newChat: () => {
        const id = uid();
        const chat: Conversation = {
          id,
          title: "",
          messages: [],
          updatedAt: Date.now(),
        };
        set({
          conversations: [chat, ...get().conversations].slice(0, MAX_CHATS),
          activeId: id,
          composerMode: "chat",
        });
        return id;
      },
      setActive: (id) => set({ activeId: id, composerMode: "chat" }),
      deleteChat: (id) => {
        const conversations = get().conversations.filter((c) => c.id !== id);
        const activeId = get().activeId === id ? (conversations[0]?.id ?? null) : get().activeId;
        set({ conversations, activeId });
      },
      appendMessage: (chatId, message) => {
        set({
          conversations: get().conversations.map((c) => {
            if (c.id !== chatId) return c;
            const messages = [...c.messages, message].slice(-MAX_MESSAGES);
            return { ...c, messages, updatedAt: Date.now() };
          }),
        });
      },
      patchMessage: (chatId, messageId, patch) => {
        set({
          conversations: get().conversations.map((c) => {
            if (c.id !== chatId) return c;
            return {
              ...c,
              updatedAt: Date.now(),
              messages: c.messages.map((m) => (m.id === messageId ? { ...m, ...patch } : m)),
            };
          }),
        });
      },
      touchTitle: (chatId, title) => {
        set({
          conversations: get().conversations.map((c) =>
            c.id === chatId && !c.title ? { ...c, title } : c,
          ),
        });
      },
      removeLastAssistant: (chatId) => {
        set({
          conversations: get().conversations.map((c) => {
            if (c.id !== chatId) return c;
            const last = c.messages[c.messages.length - 1];
            if (!last || last.role !== "assistant") return c;
            return { ...c, messages: c.messages.slice(0, -1), updatedAt: Date.now() };
          }),
        });
      },
    }),
    {
      name: "nura-store",
      partialize: (s) => ({
        locale: s.locale,
        theme: s.theme,
        conversations: s.conversations,
        activeId: s.activeId,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated();
      },
    },
  ),
);

export function ensureChatId(): string {
  const s = useNuraStore.getState();
  if (s.activeId) {
    const exists = s.conversations.some((c) => c.id === s.activeId);
    if (exists) return s.activeId;
  }
  return s.newChat();
}

export { uid };

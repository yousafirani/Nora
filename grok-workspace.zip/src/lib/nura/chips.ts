const START = "<<chips>>";
const END = "<<end>>";

export function takeChips(text: string): { content: string; chips: string[] } {
  const start = text.indexOf(START);
  if (start === -1) {
    const dangling = text.lastIndexOf("<<");
    if (dangling >= 0 && text.length - dangling < 20) {
      return { content: text.slice(0, dangling).trimEnd(), chips: [] };
    }
    return { content: text, chips: [] };
  }
  const after = text.slice(start + START.length);
  const endAt = after.indexOf(END);
  const raw = (endAt >= 0 ? after.slice(0, endAt) : after).trim();
  const chips = raw
    .split("\n")
    .map((line) => line.replace(/^[-*\d.]+\s*/, "").trim())
    .filter((line) => line.length > 0 && line !== END)
    .slice(0, 3);
  return { content: text.slice(0, start).trimEnd(), chips };
}

export type Locale = "fa" | "en";
export type Theme = "light" | "dark";
export type Role = "user" | "assistant";
export type ComposerMode = "chat" | "image";
export type LivePhase = "listening" | "thinking" | "speaking";

export type ChatMessage = {
  id: string;
  role: Role;
  content: string;
  imageUrl?: string;
  attachedImage?: string;
  createdAt: number;
  error?: boolean;
  suggestions?: string[];
  citations?: string[];
};

export type Conversation = {
  id: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: number;
};

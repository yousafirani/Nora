import { Fragment, type ReactNode } from "react";
import { dirForText } from "./i18n";

type Block =
  | { kind: "p"; text: string }
  | { kind: "h"; text: string }
  | { kind: "ul"; items: string[] }
  | { kind: "ol"; items: string[] }
  | { kind: "code"; lang: string; text: string }
  | { kind: "quote"; text: string };

function parseBlocks(src: string): Block[] {
  const lines = src.replace(/\r\n/g, "\n").split("\n");
  const blocks: Block[] = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i] ?? "";
    if (line.startsWith("```")) {
      const lang = line.slice(3).trim();
      const buf: string[] = [];
      i += 1;
      while (i < lines.length && !(lines[i] ?? "").startsWith("```")) {
        buf.push(lines[i] ?? "");
        i += 1;
      }
      i += 1;
      blocks.push({ kind: "code", lang, text: buf.join("\n") });
      continue;
    }
    if (/^#{1,3}\s+\S/.test(line)) {
      blocks.push({ kind: "h", text: line.replace(/^#{1,3}\s+/, "") });
      i += 1;
      continue;
    }
    if (/^\s*[-*]\s+\S/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i] ?? "")) {
        items.push((lines[i] ?? "").replace(/^\s*[-*]\s+/, ""));
        i += 1;
      }
      blocks.push({ kind: "ul", items });
      continue;
    }
    if (/^\s*\d+\.\s+\S/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i] ?? "")) {
        items.push((lines[i] ?? "").replace(/^\s*\d+\.\s+/, ""));
        i += 1;
      }
      blocks.push({ kind: "ol", items });
      continue;
    }
    if (/^>\s?/.test(line)) {
      const buf: string[] = [];
      while (i < lines.length && /^>\s?/.test(lines[i] ?? "")) {
        buf.push((lines[i] ?? "").replace(/^>\s?/, ""));
        i += 1;
      }
      blocks.push({ kind: "quote", text: buf.join(" ") });
      continue;
    }
    if (!line.trim()) {
      i += 1;
      continue;
    }
    const buf: string[] = [line];
    i += 1;
    while (i < lines.length && (lines[i] ?? "").trim() && !/^(```|#{1,3}\s+|[-*]\s+|\d+\.\s+|>\s?)/.test(lines[i] ?? "")) {
      buf.push(lines[i] ?? "");
      i += 1;
    }
    blocks.push({ kind: "p", text: buf.join(" ") });
  }
  return blocks;
}

function inline(text: string): ReactNode[] {
  const parts: ReactNode[] = [];
  const re = /(\*\*[^*]+?\*\*|`[^`]+`|\*[^*]+?\*)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const token = m[0];
    if (token.startsWith("**")) {
      parts.push(
        <strong key={k++} className="font-medium text-fg">
          {token.slice(2, -2)}
        </strong>,
      );
    } else if (token.startsWith("`")) {
      parts.push(
        <code key={k++} className="rounded-sm bg-chip px-1 py-0.5 font-mono text-sm text-fg">
          {token.slice(1, -1)}
        </code>,
      );
    } else {
      parts.push(
        <em key={k++} className="italic">
          {token.slice(1, -1)}
        </em>,
      );
    }
    last = m.index + token.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

export function MarkdownBody({ text }: { text: string }) {
  const blocks = parseBlocks(text);
  if (blocks.length === 0) return null;
  return (
    <div className="flex flex-col gap-3 text-pretty" dir={dirForText(text)}>
      {blocks.map((b, i) => {
        if (b.kind === "h") {
          return (
            <h3 key={i} className="text-base font-medium tracking-tight text-fg text-balance">
              {inline(b.text)}
            </h3>
          );
        }
        if (b.kind === "ul") {
          return (
            <ul key={i} className="flex list-disc flex-col gap-1 ps-5">
              {b.items.map((item, j) => (
                <li key={j}>{inline(item)}</li>
              ))}
            </ul>
          );
        }
        if (b.kind === "ol") {
          return (
            <ol key={i} className="flex list-decimal flex-col gap-1 ps-5">
              {b.items.map((item, j) => (
                <li key={j}>{inline(item)}</li>
              ))}
            </ol>
          );
        }
        if (b.kind === "code") {
          return (
            <pre
              key={i}
              className="overflow-x-auto rounded-lg bg-chip px-3 py-3 font-mono text-sm leading-relaxed text-fg"
              dir="ltr"
            >
              <code>{b.text}</code>
            </pre>
          );
        }
        if (b.kind === "quote") {
          return (
            <blockquote key={i} className="border-s-2 border-primary/40 ps-3 text-muted">
              {inline(b.text)}
            </blockquote>
          );
        }
        return (
          <p key={i} className="leading-normal">
            {inline(b.text)}
          </p>
        );
      })}
    </div>
  );
}

export function StreamingCaret() {
  return (
    <span className="ms-0.5 inline-block h-4 w-0.5 translate-y-0.5 bg-primary align-baseline animate-caret" />
  );
}

export function EmptyFrag() {
  return <Fragment />;
}

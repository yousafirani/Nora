import type { Locale } from "./types";

export type SpeechRec = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((ev: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
};

export function getSpeechCtor(): (new () => SpeechRec) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRec;
    webkitSpeechRecognition?: new () => SpeechRec;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function speakText(
  text: string,
  locale: Locale,
  opts?: { onend?: () => void; maxChars?: number },
): void {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    opts?.onend?.();
    return;
  }
  window.speechSynthesis.cancel();
  const clipped = text.replace(/\s+/g, " ").trim().slice(0, opts?.maxChars ?? 1200);
  if (!clipped) {
    opts?.onend?.();
    return;
  }
  const u = new SpeechSynthesisUtterance(clipped);
  u.lang = locale === "fa" ? "fa-IR" : "en-US";
  u.rate = 1.02;
  u.onend = () => opts?.onend?.();
  u.onerror = () => opts?.onend?.();
  window.speechSynthesis.speak(u);
}

export function stopSpeaking(): void {
  if (typeof window !== "undefined") window.speechSynthesis?.cancel();
}

import { createFileRoute } from "@tanstack/react-router";
import { NuraApp } from "@/components/nura/nura-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <NuraApp />;
}

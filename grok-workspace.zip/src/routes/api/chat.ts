import { createFileRoute } from "@tanstack/react-router";
import {
  CHAT_MODEL,
  MAX_OUTPUT_TOKENS,
  clampPrompt,
  getApiKey,
  toApiMessages,
  type ChatTurn,
} from "@/lib/ai/xai.server";
import type { Locale } from "@/lib/nura/types";

type Body = {
  locale?: Locale;
  messages?: ChatTurn[];
  search?: boolean;
};

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = getApiKey();
        if (!apiKey) {
          return Response.json({ error: "unavailable" }, { status: 503 });
        }

        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return Response.json({ error: "invalid" }, { status: 400 });
        }

        const locale: Locale = body.locale === "en" ? "en" : "fa";
        const search = body.search === true;
        const raw = Array.isArray(body.messages) ? body.messages : [];
        const turns: ChatTurn[] = raw
          .filter((m) => m && (m.role === "user" || m.role === "assistant"))
          .map((m) => ({
            role: m.role,
            content: clampPrompt(typeof m.content === "string" ? m.content : ""),
            imageUrl: typeof m.imageUrl === "string" ? m.imageUrl.slice(0, 500_000) : undefined,
            attachedImage:
              typeof m.attachedImage === "string" ? m.attachedImage.slice(0, 500_000) : undefined,
          }))
          .filter((m) => m.content || m.attachedImage || m.imageUrl);

        if (turns.length === 0) {
          return Response.json({ error: "empty" }, { status: 400 });
        }

        const payload: Record<string, unknown> = {
          model: CHAT_MODEL,
          stream: true,
          max_tokens: MAX_OUTPUT_TOKENS,
          temperature: 0.7,
          messages: toApiMessages(locale, turns, search),
        };
        if (search) {
          payload.search_parameters = {
            mode: "on",
            max_search_results: 6,
            return_citations: true,
          };
        }

        const upstream = await fetch("https://api.x.ai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify(payload),
        });

        if (!upstream.ok || !upstream.body) {
          const status = upstream.status === 429 ? 429 : 502;
          return Response.json({ error: "upstream" }, { status });
        }

        return new Response(upstream.body, {
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache, no-transform",
            Connection: "keep-alive",
          },
        });
      },
    },
  },
});

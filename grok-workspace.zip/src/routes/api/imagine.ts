import { createFileRoute } from "@tanstack/react-router";
import { IMAGE_MODEL, clampPrompt, getApiKey } from "@/lib/ai/xai.server";

type Body = { prompt?: string };

export const Route = createFileRoute("/api/imagine")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = getApiKey();
        if (!apiKey) {
          return Response.json({ ok: false as const, error: "unavailable" }, { status: 503 });
        }

        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return Response.json({ ok: false as const, error: "invalid" }, { status: 400 });
        }

        const prompt = clampPrompt(typeof body.prompt === "string" ? body.prompt : "");
        if (prompt.length < 3) {
          return Response.json({ ok: false as const, error: "empty" }, { status: 400 });
        }

        const upstream = await fetch("https://api.x.ai/v1/images/generations", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model: IMAGE_MODEL,
            prompt,
            n: 1,
            resolution: "1k",
            response_format: "url",
          }),
        });

        if (!upstream.ok) {
          const status = upstream.status === 429 ? 429 : 502;
          return Response.json({ ok: false as const, error: "upstream" }, { status });
        }

        const json = (await upstream.json()) as { data?: { url?: string }[] };
        const url = json.data?.[0]?.url;
        if (!url) {
          return Response.json({ ok: false as const, error: "empty" }, { status: 502 });
        }
        return Response.json({ ok: true as const, url });
      },
    },
  },
});

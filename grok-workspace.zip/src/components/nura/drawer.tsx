import { Moon, Plus, Sun, Trash2, X } from "lucide-react";
import { STR } from "@/lib/nura/i18n";
import type { Conversation, Locale, Theme } from "@/lib/nura/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { NuraMark } from "./logo";

type Props = {
  open: boolean;
  locale: Locale;
  theme: Theme;
  conversations: Conversation[];
  activeId: string | null;
  onClose: () => void;
  onNew: () => void;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onLocale: (locale: Locale) => void;
  onTheme: (theme: Theme) => void;
};

export function ChatDrawer({
  open,
  locale,
  theme,
  conversations,
  activeId,
  onClose,
  onNew,
  onSelect,
  onDelete,
  onLocale,
  onTheme,
}: Props) {
  const t = STR[locale];

  return (
    <>
      <div
        className={cn(
          "absolute inset-0 z-40 bg-fg/30 transition-opacity duration-250",
          open ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        onClick={onClose}
        aria-hidden={!open}
      />
      <aside
        className={cn(
          "absolute inset-y-0 start-0 z-50 flex w-80 max-w-full flex-col bg-surface shadow-float transition-transform duration-250 ease-smooth",
          open ? "translate-x-0" : "ltr:-translate-x-full rtl:translate-x-full",
        )}
        aria-hidden={!open}
        aria-label={t.chats}
      >
        <div className="safe-top flex items-center justify-between px-3">
          <div className="flex items-center gap-2 px-1">
            <NuraMark className="size-5" />
            <span className="text-base font-medium">{t.appName}</span>
          </div>
          <Button variant="icon" size="iconSm" aria-label={t.close} onClick={onClose}>
            <X className="size-5" />
          </Button>
        </div>

        <div className="px-3 pt-3">
          <Button variant="chip" className="w-full justify-start rounded-xl" onClick={onNew}>
            <Plus className="size-4" />
            {t.newChat}
          </Button>
        </div>

        <p className="px-5 pb-2 pt-5 text-xs font-medium text-subtle">{t.chats}</p>
        <ul className="flex-1 overflow-y-auto px-2 pb-4">
          {conversations.length === 0 ? (
            <li className="px-3 py-6 text-sm text-muted">{t.emptyChats}</li>
          ) : (
            conversations.map((c) => (
              <li key={c.id} className="group relative">
                <button
                  type="button"
                  onClick={() => onSelect(c.id)}
                  className={cn(
                    "flex h-12 w-full items-center rounded-lg px-3 pe-11 text-start text-sm",
                    c.id === activeId ? "bg-chip text-fg" : "text-fg hover:bg-chip",
                  )}
                >
                  <span className="truncate">{c.title || t.untitled}</span>
                </button>
                <button
                  type="button"
                  aria-label={t.delete}
                  onClick={() => onDelete(c.id)}
                  className="absolute end-1 top-1/2 flex size-9 -translate-y-1/2 items-center justify-center rounded-full text-muted opacity-70 hover:bg-chip hover:text-danger"
                >
                  <Trash2 className="size-4" />
                </button>
              </li>
            ))
          )}
        </ul>

        <div className="space-y-3 border-t border-border px-4 py-4">
          <p className="text-xs font-medium text-subtle">{t.settings}</p>
          <div className="flex items-center justify-between gap-3">
            <span className="text-sm text-fg">{t.language}</span>
            <div className="flex rounded-full bg-chip p-0.5">
              <Toggle active={locale === "fa"} onClick={() => onLocale("fa")}>
                فارسی
              </Toggle>
              <Toggle active={locale === "en"} onClick={() => onLocale("en")}>
                EN
              </Toggle>
            </div>
          </div>
          <div className="flex items-center justify-between gap-3">
            <span className="text-sm text-fg">{t.theme}</span>
            <div className="flex rounded-full bg-chip p-0.5">
              <Toggle active={theme === "light"} onClick={() => onTheme("light")} aria-label={t.light}>
                <Sun className="size-4" />
              </Toggle>
              <Toggle active={theme === "dark"} onClick={() => onTheme("dark")} aria-label={t.dark}>
                <Moon className="size-4" />
              </Toggle>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}

function Toggle({
  active,
  onClick,
  children,
  ...rest
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-8 min-w-8 items-center justify-center rounded-full px-2.5 text-xs font-medium transition-colors duration-150",
        active ? "bg-surface text-fg shadow-border" : "text-muted",
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

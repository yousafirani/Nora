import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { STR } from "@/lib/nura/i18n";
import type { LivePhase, Locale } from "@/lib/nura/types";
import { NuraMark } from "./logo";

type Props = {
  open: boolean;
  phase: LivePhase;
  locale: Locale;
  onClose: () => void;
  onOrb: () => void;
};

export function LiveStage({ open, phase, locale, onClose, onOrb }: Props) {
  const t = STR[locale];
  if (!open) return null;

  const label =
    phase === "listening" ? t.listeningLive : phase === "thinking" ? t.thinkingLive : t.speakingLive;

  return (
    <div className="absolute inset-0 z-30 flex flex-col bg-bg">
      <header className="safe-top flex items-center justify-between px-2">
        <Button variant="icon" size="icon" aria-label={t.endLive} onClick={onClose}>
          <X className="size-5" />
        </Button>
        <div className="flex items-center gap-2">
          <NuraMark className="size-5" />
          <h1 className="text-base font-medium tracking-tight">{t.live}</h1>
        </div>
        <span className="size-11" aria-hidden />
      </header>

      <div className="flex flex-1 flex-col items-center justify-center px-6 pb-16">
        <button
          type="button"
          className="live-orb"
          data-phase={phase}
          onClick={onOrb}
          aria-label={t.liveHint}
        >
          <span className="live-ring" />
          <span className="live-ring live-ring-delay" />
          <NuraMark className="relative z-10 size-16" motion={phase === "speaking" ? "none" : "think"} />
        </button>
        <p className="mt-10 text-lg font-medium tracking-tight text-fg">{label}</p>
        <p className="mt-2 max-w-xs text-center text-sm text-subtle text-balance">{t.liveHint}</p>
      </div>
    </div>
  );
}

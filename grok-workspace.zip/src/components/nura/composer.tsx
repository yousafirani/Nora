import { AudioLines, Camera, Globe, ImageIcon, Mic, Paperclip, Plus, Send, Square, X } from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { STR } from "@/lib/nura/i18n";
import type { ComposerMode, Locale } from "@/lib/nura/types";
import { cn } from "@/lib/utils";

type Props = {
  locale: Locale;
  mode: ComposerMode;
  value: string;
  attached: string | null;
  listening: boolean;
  busy: boolean;
  searchOn: boolean;
  onChange: (value: string) => void;
  onMode: (mode: ComposerMode) => void;
  onSearch: (on: boolean) => void;
  onAttach: (file: File) => void;
  onClearAttach: () => void;
  onMic: () => void;
  onLive: () => void;
  onSend: () => void;
  onStop: () => void;
};

export function Composer({
  locale,
  mode,
  value,
  attached,
  listening,
  busy,
  searchOn,
  onChange,
  onMode,
  onSearch,
  onAttach,
  onClearAttach,
  onMic,
  onLive,
  onSend,
  onStop,
}: Props) {
  const t = STR[locale];
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const camRef = useRef<HTMLInputElement>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const el = taRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
  }, [value]);

  const canSend = (value.trim().length > 0 || Boolean(attached)) && !busy;

  return (
    <div className="safe-bottom relative px-3 pb-3 pt-1">
      {attached ? (
        <div className="mb-2 flex items-center gap-2">
          <div className="relative">
            <img
              src={attached}
              alt=""
              className="h-16 w-16 rounded-md object-cover outline outline-1 -outline-offset-1 outline-fg/10"
            />
            <button
              type="button"
              onClick={onClearAttach}
              className="absolute -end-1.5 -top-1.5 flex size-6 items-center justify-center rounded-full bg-fg text-bg"
              aria-label={t.close}
            >
              <X className="size-3" strokeWidth={2.5} />
            </button>
          </div>
        </div>
      ) : null}

      {menuOpen ? (
        <>
          <button
            type="button"
            className="fixed inset-0 z-20 bg-fg/10"
            aria-label={t.close}
            onClick={() => setMenuOpen(false)}
          />
          <div className="absolute inset-x-3 bottom-full z-30 mb-2 rounded-3xl bg-surface p-3 shadow-float">
            <div className="grid grid-cols-2 gap-2">
              <ToolTile
                icon={<Paperclip className="size-4 text-primary" />}
                label={t.gallery}
                onClick={() => {
                  setMenuOpen(false);
                  fileRef.current?.click();
                }}
              />
              <ToolTile
                icon={<Camera className="size-4 text-primary" />}
                label={t.camera}
                onClick={() => {
                  setMenuOpen(false);
                  camRef.current?.click();
                }}
              />
              <ToolTile
                icon={<ImageIcon className="size-4 text-primary" />}
                label={t.createImage}
                onClick={() => {
                  setMenuOpen(false);
                  onMode(mode === "image" ? "chat" : "image");
                }}
              />
              <ToolTile
                icon={<Globe className="size-4 text-primary" />}
                label={t.search}
                onClick={() => {
                  setMenuOpen(false);
                  onSearch(!searchOn);
                }}
              />
              <ToolTile
                icon={<AudioLines className="size-4 text-primary" />}
                label={t.live}
                wide
                onClick={() => {
                  setMenuOpen(false);
                  onLive();
                }}
              />
            </div>
          </div>
        </>
      ) : null}

      {(searchOn || mode === "image") && (
        <div className="mb-2 flex flex-wrap gap-1.5">
          {searchOn ? (
            <ToolChip label={t.searchOn} onClear={() => onSearch(false)} closeLabel={t.close} />
          ) : null}
          {mode === "image" ? (
            <ToolChip label={t.imageMode} onClear={() => onMode("chat")} closeLabel={t.close} />
          ) : null}
        </div>
      )}

      <div
        className={cn(
          "relative z-30 flex items-end gap-1 rounded-3xl bg-surface p-1.5 shadow-border",
          listening && "ring-2 ring-primary/30",
        )}
      >
        <Button
          variant="icon"
          size="iconSm"
          aria-label={t.attach}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((o) => !o)}
        >
          <Plus className={cn("size-5 transition-transform duration-150 ease-smooth", menuOpen && "rotate-45")} />
        </Button>

        <textarea
          ref={taRef}
          rows={1}
          value={value}
          enterKeyHint="send"
          autoComplete="off"
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setMenuOpen(false)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              if (canSend) onSend();
            }
          }}
          onPaste={(e) => {
            const file = [...e.clipboardData.files].find((f) => f.type.startsWith("image/"));
            if (file) {
              e.preventDefault();
              onAttach(file);
            }
          }}
          placeholder={listening ? t.listening : mode === "image" ? t.placeholderImage : t.placeholder}
          className="max-h-40 min-h-10 flex-1 resize-none bg-transparent py-2.5 text-base leading-snug text-fg outline-none placeholder:text-subtle"
        />

        {busy ? (
          <Button variant="primary" size="iconSm" aria-label={t.stop} onClick={onStop}>
            <Square className="size-3.5 fill-current" />
          </Button>
        ) : canSend ? (
          <Button variant="primary" size="iconSm" aria-label={t.send} onClick={onSend}>
            {mode === "image" ? <ImageIcon className="size-4" /> : <Send className="size-4" />}
          </Button>
        ) : (
          <Button
            variant="icon"
            size="iconSm"
            aria-label={t.listening}
            aria-pressed={listening}
            onClick={onMic}
            className={listening ? "text-primary" : undefined}
          >
            <Mic className="size-5" />
          </Button>
        )}
      </div>

      <p className="mt-1.5 px-2 text-center text-xs text-subtle">{t.powered}</p>

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) onAttach(file);
        }}
      />
      <input
        ref={camRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) onAttach(file);
        }}
      />
    </div>
  );
}

function ToolTile({
  icon,
  label,
  onClick,
  wide,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  wide?: boolean;
}) {
  return (
    <button
      type="button"
      className={cn(
        "flex min-h-16 flex-col items-start justify-center gap-2 rounded-xl bg-chip px-3.5 py-3 text-start text-sm font-medium text-fg transition-[background-color,transform] duration-150 hover:bg-chip-hover active:scale-[0.98]",
        wide && "col-span-2 min-h-12 flex-row items-center",
      )}
      onClick={onClick}
    >
      {icon}
      {label}
    </button>
  );
}

function ToolChip({
  label,
  onClear,
  closeLabel,
}: {
  label: string;
  onClear: () => void;
  closeLabel: string;
}) {
  return (
    <span className="inline-flex h-8 max-w-full items-center gap-1 rounded-full bg-chip px-3 text-xs font-medium text-fg">
      <span className="truncate">{label}</span>
      <button type="button" onClick={onClear} aria-label={closeLabel} className="flex size-5 items-center justify-center">
        <X className="size-3" />
      </button>
    </span>
  );
}

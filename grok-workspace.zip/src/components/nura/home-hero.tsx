import { CalendarDays, ImageIcon, Languages, ListChecks, PenLine, Sparkle } from "lucide-react";
import { greetingForHour, STR, type Copy } from "@/lib/nura/i18n";
import type { Locale } from "@/lib/nura/types";
import { NuraMark } from "./logo";

const CHIP_ICONS = {
  write: PenLine,
  explain: Sparkle,
  image: ImageIcon,
  translate: Languages,
  plan: CalendarDays,
  summarize: ListChecks,
} as const;

type ChipKey = keyof Copy["chips"];

export function HomeHero({
  locale,
  hour,
  onChip,
  onLive,
}: {
  locale: Locale;
  hour: number;
  onChip: (key: ChipKey) => void;
  onLive: () => void;
}) {
  const t = STR[locale];
  const keys = Object.keys(t.chips) as ChipKey[];

  return (
    <div className="flex flex-1 flex-col overflow-y-auto">
      <div className="flex min-h-full flex-col items-center justify-center px-5 py-3">
        <div className="flex flex-col items-center gap-4">
          <div className="stagger-item flex size-20 items-center justify-center">
            <NuraMark className="size-16" motion="breathe" />
          </div>
          <div className="stagger-item flex flex-col items-center gap-1.5 text-center">
            <p className="greeting-text text-4xl font-medium tracking-display text-balance">
              {greetingForHour(locale, hour)}
            </p>
            <p className="text-base text-muted">{t.subtitle}</p>
          </div>
        </div>

        <button
          type="button"
          onClick={onLive}
          className="stagger-item mt-5 flex h-11 items-center gap-2 rounded-full bg-chip px-5 text-sm font-medium text-fg transition-[background-color,transform] duration-150 ease-smooth hover:bg-chip-hover active:scale-[0.96]"
        >
          <NuraMark className="size-4" />
          {t.live}
        </button>

        <ul className="mt-6 grid w-full grid-cols-2 gap-2">
          {keys.map((key, i) => {
            const Icon = CHIP_ICONS[key];
            return (
              <li key={key} className="stagger-item" style={{ animationDelay: `${80 + i * 40}ms` }}>
                <button
                  type="button"
                  onClick={() => onChip(key)}
                  className="flex h-full min-h-14 w-full flex-col items-start gap-1.5 rounded-2xl bg-chip px-3.5 py-2.5 text-start transition-[background-color,transform] duration-150 ease-out hover:bg-chip-hover active:scale-[0.98]"
                >
                  <Icon className="size-4 text-primary" strokeWidth={1.75} />
                  <span className="text-sm font-medium leading-snug text-fg">{t.chips[key].label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

import { cn } from "@/lib/utils";

type Motion = "none" | "breathe" | "think";

export function NuraMark({
  className,
  motion = "none",
}: {
  className?: string;
  motion?: Motion;
}) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={cn(
        "nura-mark",
        motion === "breathe" && "nura-mark-breathe",
        motion === "think" && "nura-mark-think",
        className,
      )}
      aria-hidden="true"
    >
      <path className="fill-spark-a" d="M32 4C34.2 16.8 42 24.4 32 32 22 24.4 29.8 16.8 32 4Z" />
      <path className="fill-spark-d" d="M60 32C47.2 29.8 39.6 22 32 32 39.6 42 47.2 34.2 60 32Z" />
      <path className="fill-spark-c" d="M32 60C29.8 47.2 22 39.6 32 32 42 39.6 34.2 47.2 32 60Z" />
      <path className="fill-spark-b" d="M4 32C16.8 34.2 24.4 42 32 32 24.4 22 16.8 29.8 4 32Z" />
    </svg>
  );
}

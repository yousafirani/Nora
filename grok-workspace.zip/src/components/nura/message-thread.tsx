import { Copy, Download, RotateCw, Volume2, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { NuraMark } from "@/components/nura/logo";
import { STR, dirForText, hostnameOf } from "@/lib/nura/i18n";
import { MarkdownBody, StreamingCaret } from "@/lib/nura/markdown";
import type { ChatMessage, Locale } from "@/lib/nura/types";
import { cn } from "@/lib/utils";

type Props = {
  locale: Locale;
  messages: ChatMessage[];
  streamingId: string | null;
  thinking: boolean;
  drawing: boolean;
  busy: boolean;
  onFollowUp: (text: string) => void;
  onRegenerate: () => void;
};

export function MessageThread({
  locale,
  messages,
  streamingId,
  thinking,
  drawing,
  busy,
  onFollowUp,
  onRegenerate,
}: Props) {
  const t = STR[locale];
  const end = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState<string | null>(null);
  const lastAssistantId = [...messages].reverse().find((m) => m.role === "assistant")?.id;

  useEffect(() => {
    end.current?.scrollIntoView({ block: "end" });
  }, [messages, thinking, drawing]);

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4">
      <ol className="flex flex-col gap-5">
        {messages.map((m) => {
          const streaming = m.id === streamingId;
          if (m.role === "user") {
            return (
              <li key={m.id} className="flex flex-col items-end gap-2">
                {m.attachedImage ? (
                  <button type="button" onClick={() => setZoom(m.attachedImage!)} className="max-w-[72%]">
                    <img
                      src={m.attachedImage}
                      alt=""
                      className="max-h-52 w-full rounded-xl object-cover outline outline-1 -outline-offset-1 outline-fg/10"
                    />
                  </button>
                ) : null}
                {m.content ? (
                  <div
                    dir={dirForText(m.content)}
                    className="max-w-[85%] rounded-2xl rounded-se-md bg-chip px-3.5 py-2.5 text-base leading-normal text-fg"
                  >
                    {m.content}
                  </div>
                ) : null}
              </li>
            );
          }
          const isLast = m.id === lastAssistantId && !streaming && !busy;
          return (
            <li key={m.id} className="flex flex-col items-stretch gap-3">
              <div className="flex items-center gap-2 text-subtle">
                <NuraMark className="size-4" />
                <span className="text-xs font-medium tracking-wide">{t.nura}</span>
              </div>
              {m.imageUrl ? (
                <div className="relative">
                  <button type="button" onClick={() => setZoom(m.imageUrl!)} className="block w-full">
                    <img
                      src={m.imageUrl}
                      alt={m.content}
                      className="w-full rounded-xl object-cover outline outline-1 -outline-offset-1 outline-fg/10"
                    />
                  </button>
                  <a
                    href={m.imageUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="absolute end-2 top-2 flex size-9 items-center justify-center rounded-full bg-bg/80 text-fg shadow-border"
                    aria-label={t.download}
                  >
                    <Download className="size-4" />
                  </a>
                </div>
              ) : null}
              {m.content || streaming ? (
                <div className={cn("text-base leading-normal text-fg", m.error && "text-danger")}>
                  {m.content ? <MarkdownBody text={m.content} /> : null}
                  {streaming ? <StreamingCaret /> : null}
                </div>
              ) : null}
              {m.citations && m.citations.length > 0 ? (
                <div>
                  <p className="mb-1.5 text-xs font-medium text-subtle">{t.sources}</p>
                  <ul className="flex flex-wrap gap-1.5">
                    {m.citations.map((url) => (
                      <li key={url}>
                        <a
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex h-8 items-center rounded-full bg-chip px-3 text-xs text-fg hover:bg-chip-hover"
                        >
                          {hostnameOf(url)}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
              {!streaming && m.content && !m.error ? (
                <div className="flex gap-1">
                  <button
                    type="button"
                    className="flex size-9 items-center justify-center rounded-full text-muted hover:bg-chip hover:text-fg"
                    aria-label={t.copy}
                    onClick={async () => {
                      await navigator.clipboard.writeText(m.content);
                      toast(t.copied);
                    }}
                  >
                    <Copy className="size-4" />
                  </button>
                  <button
                    type="button"
                    className="flex size-9 items-center justify-center rounded-full text-muted hover:bg-chip hover:text-fg"
                    aria-label={t.speak}
                    onClick={() => {
                      if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
                      window.speechSynthesis.cancel();
                      const u = new SpeechSynthesisUtterance(m.content);
                      u.lang = locale === "fa" ? "fa-IR" : "en-US";
                      window.speechSynthesis.speak(u);
                    }}
                  >
                    <Volume2 className="size-4" />
                  </button>
                  {isLast ? (
                    <button
                      type="button"
                      className="flex size-9 items-center justify-center rounded-full text-muted hover:bg-chip hover:text-fg"
                      aria-label={t.regenerate}
                      onClick={onRegenerate}
                    >
                      <RotateCw className="size-4" />
                    </button>
                  ) : null}
                </div>
              ) : null}
              {isLast && m.suggestions && m.suggestions.length > 0 ? (
                <ul className="flex flex-wrap gap-1.5 pt-1">
                  {m.suggestions.map((s) => (
                    <li key={s}>
                      <button
                        type="button"
                        onClick={() => onFollowUp(s)}
                        className="inline-flex min-h-9 items-center rounded-full bg-chip px-3.5 py-1.5 text-sm text-fg transition-[background-color,transform] duration-150 hover:bg-chip-hover active:scale-[0.98]"
                      >
                        {s}
                      </button>
                    </li>
                  ))}
                </ul>
              ) : null}
            </li>
          );
        })}
        {thinking || drawing ? (
          <li className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-subtle">
              <NuraMark className="size-4" motion="think" />
              <span className="text-xs font-medium">{drawing ? t.drawing : t.thinking}</span>
            </div>
            <p className="shimmer-text text-sm text-muted">{drawing ? t.drawing : t.thinking}</p>
          </li>
        ) : null}
      </ol>
      <div ref={end} />

      {zoom ? (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-fg/80 p-4">
          <button
            type="button"
            className="absolute end-3 top-3 flex size-11 items-center justify-center rounded-full bg-bg text-fg"
            aria-label={t.close}
            onClick={() => setZoom(null)}
          >
            <X className="size-5" />
          </button>
          <img src={zoom} alt="" className="max-h-full max-w-full rounded-lg object-contain" onClick={() => setZoom(null)} />
        </div>
      ) : null}
    </div>
  );
}
